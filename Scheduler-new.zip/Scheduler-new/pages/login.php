<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="../styles/style.css?<?php echo time();?>" media="screen" />
	<link rel="stylesheet" type="text/css" href="../styles/font-awesome/css/font-awesome.min.css" media="screen" />
    <script src="../scripts/script.js"></script>
    <meta charset="utf-8"/>
    <title id="tab_name">Profile</title>
</head>

<body>
    <!--Logo-->
    <?php require '../shared/logo.php' ; ?>
    <?php require '../shared/tutor-nav.php' ; ?>

    <!--Page Contents-->
    <div class="content-item">
       <h2> Welcome Tutor Name <a class="edit_icon" href="tutor-profile.php"><i class="icon-pencil"></i> </a></h2>





    </div>
</body>
</html>

