<div id="nav">
    <ul id="tutor-nav">
        <li onclick="goToPage('tutor-calendar');">Calendar</li>
        <li onclick="goToPage('tutor-appointments');">Appointments</li>
        <li onclick="goToPage('tutor-sections');">Sections</li>
        <li onclick="goToPage('tutor-profile');">Profile</li>
        <li onclick="goToPage('splash');">Logout</li>
    </ul>
</div>