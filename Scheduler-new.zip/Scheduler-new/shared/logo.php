<div id="logo">
    <h1 id="logo-text">Scheduler</h1>
</div>