<div id="nav">
    <ul id="student-nav">
        <li onclick="goToPage('splash');">Menu</li> 
    </ul>
</div>