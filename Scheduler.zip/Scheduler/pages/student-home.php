<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="../styles/style.css?stssuff" media="screen" />
    <script src="../scripts/script.js"></script>
    <meta charset="utf-8"/>
    <title id="tab_name">Student</title>
</head>

<body>
    <!--Nav Bar + Logo-->
    <?php require '../shared/logo.php' ; ?>

    <!--Page Contents-->
    <div class="content-item">
        <div>
            <h1></h1>
        </div>
    </div>
</body>
</html>

